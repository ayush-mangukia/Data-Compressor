The Canterbury Corpus as a git repository
=========================================

The Canterbury Corpus is set of standardized test files ("corpus") to
test lossless archivers/compressors, prepared by University of Canterbury:
http://corpus.canterbury.ac.nz .

This project imports the contents of the corpus into a git repository, e.g.
to include as a git submodule into other repositories.

